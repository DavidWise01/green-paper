#!/usr/bin/env bash
# witness/bootstrap.sh
# break chains, chain
#
# usage:
#   curl -sSL https://raw.githubusercontent.com/<account>/witness/main/bootstrap.sh | bash -s <nonce>
#
# or, inside an AI sandbox:
#   git clone --depth 1 https://github.com/<account>/witness /tmp/witness
#   bash /tmp/witness/bootstrap.sh <nonce>

set -euo pipefail

NONCE="${1:-}"
if [ -z "$NONCE" ]; then
  echo "ERR: nonce required as first argument" >&2
  echo "  usage: bootstrap.sh <16-hex-nonce>" >&2
  exit 1
fi

if ! [[ "$NONCE" =~ ^[0-9a-fA-F]{8,64}$ ]]; then
  echo "ERR: nonce must be 8-64 hex chars" >&2
  exit 1
fi

WITNESS_DIR="${WITNESS_DIR:-/home/claude/witness}"
SESSION_DIR="${SESSION_DIR:-/home/claude/.witness-session}"

mkdir -p "$SESSION_DIR"

cat > "$SESSION_DIR/session.env" <<EOF
WITNESS_NONCE=$NONCE
WITNESS_START_ISO=$(date -Iseconds)
WITNESS_START_UNIX=$(date +%s)
WITNESS_DIR=$WITNESS_DIR
SESSION_DIR=$SESSION_DIR
EOF

echo "witness session armed"
echo "  nonce:   ${NONCE:0:8}..."
echo "  start:   $(date -Iseconds)"
echo "  dir:     $WITNESS_DIR"
echo "  session: $SESSION_DIR"

if [ -f "$WITNESS_DIR/MANIFEST.json" ]; then
  LEAVES=$(grep -c '"name"' "$WITNESS_DIR/MANIFEST.json" || echo 0)
  echo "  leaves:  ~$LEAVES indexed"
fi

echo
echo "ready · read SKILL.md before producing artifacts"
