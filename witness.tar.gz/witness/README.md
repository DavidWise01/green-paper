# witness

> break chains, chain

Central index and provenance kit for a distributed prior-art mesh.

`witness` is one repo that lets a fresh AI session find every other repo,
follow a known protocol for signing artifacts on the way out, and chain
those signed artifacts back to the session that produced them.

It is the root of the tree. The other ~100 repos are leaves.

## What it is

Three things in one repo:

1. **An index.** `MANIFEST.json` catalogs every other repo in the mesh
   with URL, SHA, purpose, and tags. One source of truth for "where
   does X live."

2. **A bootstrap.** `SKILL.md` and `bootstrap.sh` give a fresh sandbox
   AI everything it needs to know in one git-clone. From a cold start,
   any Claude / GPT / Gemini reads `SKILL.md`, parses `MANIFEST.json`,
   and fetches only the leaves it needs for the task.

3. **A provenance protocol.** `protocols/davw.md` and
   `protocols/witness.md` define the signature format and the session
   bundle format. Every artifact that leaves a sandbox is signed.
   Every session emits one bundle. The bundle is the evidence.

## What it solves

**Centralization without consolidation.** The 100 repos stay where they
are. Their hashes get pinned in `MANIFEST.json`. Touching the leaves
risks the prior-art chain; pinning them in an index does not.

**Provenance for ephemeral work.** Sandbox VMs are throwaway by design.
Anything generated inside one only counts as evidence if it leaves
signed. `witness` makes the egress moment the witnessed moment.

**Bootstrap cost.** A fresh AI session previously cost N messages of
context-pasting before useful work could start. Now it costs one:
"clone witness, read SKILL.md, here is the nonce."

## How to use it

In a fresh AI conversation, first message:

```
nonce: <16 random hex>
clone: https://github.com/<your-account>/witness
go.
```

The AI clones the repo, reads `SKILL.md`, knows where the leaves are,
and starts work. Every artifact it produces gets davw-signed with the
session nonce embedded. At session end, the AI emits one
`.witness-session-<nonce>` bundle. You download it. The bundle is your
court-ready record.

## Structure

```
witness/
  README.md               this file
  SKILL.md                fresh-AI bootstrap instructions
  MANIFEST.json           index of all leaf repos
  bootstrap.sh            shell-side fetch helper
  LICENSE.md              davw license
  protocols/
    davw.md               signature format spec
    witness.md            session bundle format spec
  .witness/
    manifest.template.json   template for adding a repo
```

## License

`davw` — origin=davw; use=pay Dave; attribution required.

See `LICENSE.md`.

---

`davw:witness` · DLW · 2026
