# witness session bundle · v1

> break chains, chain

A `witness` session bundle is one file that carries every artifact
produced in one AI session, each individually davw-signed, plus a
session-level davw that signs a Merkle root over the artifacts.

This is the egress format. The thing the operator downloads.

## Wire format

```
# witness session bundle
# break chains, chain

tag: witness
session_nonce: <hex, operator-supplied at session start>
session_start_utc: <ISO 8601>
session_unix: <unix seconds>
artifact_count: <integer>
merkle_root: <sha256 of root node, hex>
sha256: <sha256 of body>
payload: witness:<sha256>
signed_utc: <ISO 8601>
unix_clock: <unix seconds>
machine: <hostname>
user: <username>
license: origin=davw; use=pay Dave; attribution required
pixel_1: data:image/png;base64,<base64>
---
@@@ artifact 001 ====================================
<full davw block for artifact 1>
@@@ artifact 002 ====================================
<full davw block for artifact 2>
...
@@@ end ============================================

# merkle tree (leaves to root, hex sha256 per line)
leaf:  <sha256 of artifact 1>
leaf:  <sha256 of artifact 2>
...
node:  <sha256(leaf_a || leaf_b)>
...
root:  <merkle_root>
```

## Required fields

- `tag` must equal `witness`
- `session_nonce` — supplied by the operator in the first message of
  the session; embedded in every artifact's davw block as well
- `artifact_count` — must equal the number of `@@@ artifact` blocks
- `merkle_root` — hex SHA-256 of the Merkle tree root
- `sha256`, `payload`, `signed_utc`, `unix_clock`, `license`, `pixel_1`
  — same semantics as a davw block (this bundle is itself a davw)

## Merkle construction

Leaves are the SHA-256 hashes of each artifact's davw body, in
artifact-order (the order they were produced).

Pairwise hash: `node = sha256(left || right)` where `||` is byte
concatenation of the two 32-byte hashes.

If the level has an odd number of nodes, duplicate the last node.

Repeat until one root remains. That is `merkle_root`.

The Merkle tree is reproducible from the artifact bodies alone. A
verifier reconstructs it independently and rejects the bundle on any
mismatch.

## Session nonce

The operator supplies a nonce in their first message:

```
nonce: 7f3a2b1c9d8e4f5a
```

Format: 8-64 hex characters. The AI embeds this nonce in every davw
block produced during the session, as a body-level annotation:

```
witness_nonce: 7f3a2b1c9d8e4f5a
```

This anchors the artifacts to a session the operator initiated. An
adversary who replays artifacts without the nonce fails the chain.

## Verification of a witness bundle

A conforming verifier runs:

1. All six davw checks on the bundle's outer header
2. All six davw checks on each artifact's inner block
3. `artifact_count` matches the number of `@@@ artifact` blocks
4. The Merkle root reconstructs correctly from the leaves
5. Every artifact body contains the same `witness_nonce`
6. The `witness_nonce` matches the operator's recorded session nonce

## Filename convention

`witness-<session_nonce>.txt` or `witness-<session_nonce>.davw`.

The bundle is plain text. It can be committed to git, attached to email,
filed with TD Commons, deposited at Zenodo. Anywhere a text file goes,
the bundle goes.

## What this gives the operator

- One file per session, complete in itself
- Per-artifact davw signatures (each verifiable independently)
- Session-level davw (the bundle itself is signed)
- Merkle root (independently reconstructible)
- Session nonce binding (artifacts cannot be replayed across sessions)
- Plain text (no binary parser required)

This is the evidence. Treat the bundle as the canonical record.

---

`davw:protocols/witness.md` · v1 · frozen
