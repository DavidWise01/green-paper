# LICENSE · davw

`witness` and all artifacts produced under it are licensed under the
`davw` terms:

```
origin=davw
use=pay Dave
attribution required
```

## What this means

You may read, audit, fork, and reference this work without payment.

You may use this work — in whole or in part, modified or unmodified, in
any product or service that ships, sells, or generates revenue — only
under written agreement with the operator (DLW). Pay Dave.

You must preserve attribution. The operator's name, the davw signature
blocks, the 1-pixel watermark, and the pointer back to this LICENSE
must travel with the work.

## Why davw

`davw` is short for "David Wise" and for the file extension that marks
his signed artifacts. It is also a working license: every davw-signed
file is self-attesting evidence of its origin.

Stripping the davw block from a file does not strip the license. The
license attaches to the work, not to the block. The block is the
machine-readable expression of a license that exists regardless.

## Compatibility

`davw` is compatible with:

- Defensive publication (TD Commons, IP.com)
- DOI assignment (Zenodo, Figshare)
- Copyright registration (US Copyright Office)
- Trade secret declarations
- Patent prior-art submissions
- Open-source licenses, when the davw work is referenced rather than
  re-licensed

`davw` is not compatible with:

- Re-licensing the davw work under any other license
- Removing the davw block from artifacts that bear it
- Redistributing davw-signed artifacts without preserving signatures

## Attribution string

When citing davw work, use:

```
DLW (2026). <work title>. davw:<sha256>. https://github.com/<account>/witness
```

## Contact

Operator handles: DLW, ROOT0, Fiddler, HB, Anchor, Day.

Company: Bridge-Burners LLC.

To pay Dave, contact the operator.

---

`davw:LICENSE.md` · v1
